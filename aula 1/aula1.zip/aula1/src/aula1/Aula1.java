package aula1;

public class Aula1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Olá mundo");
    }
    
}
